def combine_anagrams(words)
 # YOUR CODE HERE
end
