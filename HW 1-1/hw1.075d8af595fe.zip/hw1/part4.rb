class Dessert
  def initialize(name, calories)
    # YOUR CODE HERE
  end
  
  def healthy?
    # YOUR CODE HERE
  end
  
  def delicious?
    # YOUR CODE HERE
  end
end

class JellyBean < Dessert
  def initialize(name, calories, flavor)
    # YOUR CODE HERE
  end
  
  def delicious?
    # YOUR CODE HERE
  end
end
